import React from 'react'
import MainLayout from '../shared/layouts/MainLayout'

const App: React.FC = () => {
  return <MainLayout />
}

export default App
