export interface Album {
  id: number;
  userId: number;
  title: string;
}
